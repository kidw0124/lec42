#include <stdio.h>

float add(int a, float b)
{
	float x;
	x = (float)a + b;
	return x;
}
