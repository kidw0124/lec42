#include "Graph.h"

int
main(int argc, char* argv[])
{
	Graph NFA;			/**< The input NFA. */
	Graph DFA;			/**< The output DFA. */
	char sigma[] = {'a', 'b'};	/**< The set of possible inputs. */
	vector<Set> Dstate;		/**< The set of states in DFA. */
	int T = 0;			/**< The state number in DFA. */

	if(argc<2) {
		cerr<<"Usage : "<<argv[0]<<" <input file>"<<endl;
		return 1;
	}

	NFA.readFile(argv[1]);
	Dstate.push_back(NFA.getEClosure(0));

	/** TODO: Implement the subset construction algorithm. */

	cout<<DFA;
	return 0;
}
